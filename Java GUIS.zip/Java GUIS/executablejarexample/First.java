import javax.swing.*;    

public class First
{    
	First()
	{    
		JFrame frame = new JFrame("simple swing");    
		JButton button = new JButton("click");    
		
		button.setBounds(130,100,100, 40);    
		frame.add(button);    
		frame.setSize(300,400);    
		frame.setLayout(null);    
		frame.setVisible(true);    
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);    
	}    

	public static void main(String[] args) 
	{    
    	new First();    
	}    
}    