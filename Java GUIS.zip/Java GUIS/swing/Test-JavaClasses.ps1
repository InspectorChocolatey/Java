$ErrorActionPreference = "Stop";

$dir = $(Split-Path -Path $MyInvocation.MyCommand.Definition -Parent);
Write-Host $dir

$objs = Get-ChildItem -Path $dir

cd $dir;

foreach($obj in $objs)
{
    if($obj.Name -ilike "*.class" -and $obj.Name -notlike "*$*")
    {
        
        
        $name = $obj.ToString().Split(".") | Select-Object -Index 0;

        Write-Host -Object $name

        #try
        #{
        #    java $name
        #}
        #catch
        #{
        #    continue
        #}
    }
}