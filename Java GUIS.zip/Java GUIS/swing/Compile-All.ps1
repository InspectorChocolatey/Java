
$ErrorActionPreference = "Stop";

$dir = $(Split-Path -Path $MyInvocation.MyCommand.Definition -Parent);
Write-Host $dir

$objs = Get-ChildItem -Path $dir

cd $dir;

foreach($obj in $objs)
{
    if($obj.Name -ilike "*.java")
    {
        Write-Host -Object $obj
        try
        {
            javac $obj.Name;
        }
        catch
        {
            continue
        }
    }
}