import java.awt.event.*;    
import java.awt.*;    
import javax.swing.*;     

public class ColorChooser extends JFrame implements ActionListener 
{    
    JButton button;    
    Container container;

    ColorChooserExample()
    {    
        container = getContentPane();    
        container.setLayout(new FlowLayout());         
        button = new JButton("color");    
        button.addActionListener(this);         
        container.add(button);    
    }    

    public void actionPerformed(ActionEvent e) 
    {    
    	Color initialcolor = Color.RED;    
    	Color color = JColorChooser.showDialog(this, "Select a color", initialcolor);    
    	container.setBackground(color);    
    }    
        
    public static void main(String[] args) 
    {    
        ColorChooser chooser = new ColorChooser();    
        chooser.setSize(400,400);    
        chooser.setVisible(true);    
        chooser.setDefaultCloseOperation(EXIT_ON_CLOSE);    
    }    
}    