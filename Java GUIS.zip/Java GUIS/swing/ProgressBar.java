import javax.swing.*;    

public class ProgressBar extends JFrame
{    
    JProgressBar progbar;    
    int i = 0, num = 0;     

    ProgressBarExample()
    {    
    	progbar = new JProgressBar(0,2000);    
    	progbar.setBounds(40,40,160,30);         
    	progbar.setValue(0);    
    	progbar.setStringPainted(true);    
    	add(progbar);    
    	setSize(250,150);    
    	setLayout(null);    
    }    

    public void iterate()
    {    
    	while(i <= 2000)
    	{    
      		progbar.setValue(i);    
      		i = i + 20;    
      		try
      		{
      			Thread.sleep(150);
      		}
      		catch(Exception e)
      		{

      		}    
    	}    
    }
    public static void main(String[] args) 
    {    
        ProgressBar bar = new ProgressBar();    
        bar.setVisible(true);    
        bar.iterate();    
    }    
}    