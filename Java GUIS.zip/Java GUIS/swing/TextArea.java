import javax.swing.*;  

public class TextArea  
{  
	TextArea()
	{  
        JFrame frame = new JFrame();  
        JTextArea area = new JTextArea("Swing TextArea");  
        area.setBounds(10,30, 200,200);  
        frame.add(area);  
        frame.setSize(300,300);  
        frame.setLayout(null);  
        frame.setVisible(true);  
    }  
    
    public static void main(String args[])  
    {  
    	new TextArea();  
    }
}  