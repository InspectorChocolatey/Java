import javax.swing.*;  

public class List  
{  
	List()
	{  
		JFrame frame = new JFrame();  
		DefaultListModel<String> list = new DefaultListModel<>();  
        list.addElement("Item1");  
        list.addElement("Item2");  
		list.addElement("Item3");  
		list.addElement("Item4");  
		JList<String> list = new JList<>(list);  
        list.setBounds(100,100, 75,75);  
        frame.add(list);  
        frame.setSize(400,400);  
        frame.setLayout(null);  
        frame.setVisible(true);  
    }  

    public static void main(String args[])  
    {  
       new List();  
    }
}  