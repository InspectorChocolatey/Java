import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*;  

public class Dialog
{  
	private static JDialog dialog;  
	
	Dialog() 
	{  
        JFrame frame = new JFrame();  
        dialog = new JDialog(frame,"Swing Dialog",true);  
        dialog.setLayout(new FlowLayout());  
		JButton button = new JButton("OK");  
		
		button.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e)  
			{  
                Dialog.dialog.setVisible(false);  
            }  
        });  
    
        dialog.add(new JLabel("Click button to continue."));  
        dialog.add(button);   
        dialog.setSize(300,300);    
        dialog.setVisible(true);  
    }  

    public static void main(String args[])  
    {  
        new Dialog();  
    }  
}  