import javax.swing.*;    
import java.awt.event.*;    

public class ComboBox
{    
    JFrame frame;  

    ComboBox()
    {    
        frame = new JFrame("Swing ComboBox");   
        final JLabel label = new JLabel();          
        
        label.setHorizontalAlignment(JLabel.CENTER);  
        label.setSize(400,100);  
        
        JButton button = new JButton("Show");  
        
        button.setBounds(200,100,75,20);  
        
        String languages[] = {"C","C++","C#","Java","PHP"};        
        
        final JComboBox combobox = new JComboBox(languages);    
        combobox.setBounds(50, 100,90,20);    
        frame.add(combobox); frame.add(label); frame.add(button);    
        frame.setLayout(null);    
        frame.setSize(350,350);    
        frame.setVisible(true);       

        button.addActionListener(new ActionListener() {  

            public void actionPerformed(ActionEvent e)
            {       
    			String data = "Programming language Selected: " + combobox.getItemAt(combobox.getSelectedIndex());  
    			label.setText(data);  
    		}
    	});          
    }    
    
    public static void main(String[] args) 
    {    
		new ComboBox();         
    }    
}    