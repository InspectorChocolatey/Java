import java.awt.*;

public class CheckboxGroupExample {
	CheckboxGroupExample() {
		Frame frame = new Frame("Awt CheckboxGroup");
		CheckboxGroup cbg = new CheckboxGroup();
		Checkbox checkBox1 = new Checkbox("C++", cbg, false);
		checkBox1.setBounds(100, 100, 50, 50);
		Checkbox checkBox2 = new Checkbox("Java", cbg, true);
		checkBox2.setBounds(100, 150, 50, 50);
		frame.add(checkBox1);
		frame.add(checkBox2);
		frame.setSize(400, 400);
		frame.setLayout(null);
		frame.setVisible(true);
	}

	public static void main(String args[]) {
		new CheckboxGroupExample();
	}
}