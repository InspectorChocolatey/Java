$objs = (ls $PWD | where {$_.Name -ilike "*.class"} | Select-Object -Property Name).Name

foreach($obj in $objs)
{
	java $obj;
}