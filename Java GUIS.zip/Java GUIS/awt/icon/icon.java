import java.awt.*;

class Icon {
	Icon() {
		Frame frame = new Frame();
		Image icon = Toolkit.getDefaultToolkit().getImage("D:\\icon.png");
		frame.setIconImage(icon);
		frame.setLayout(null);
		frame.setSize(400, 400);
		frame.setVisible(true);
	}

	public static void main(String args[]) {
		new Icon();
	}
}