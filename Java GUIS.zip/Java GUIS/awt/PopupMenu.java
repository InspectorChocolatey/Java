import java.awt.*;
import java.awt.event.*;

class PopupMenuExample {
	PopupMenuExample() {
		final Frame frame = new Frame("PopupMenu Example");
		final PopupMenu popupmenu = new PopupMenu("Edit");
		MenuItem cut = new MenuItem("Cut");
		cut.setActionCommand("Cut");
		MenuItem copy = new MenuItem("Copy");
		copy.setActionCommand("Copy");
		MenuItem paste = new MenuItem("Paste");
		paste.setActionCommand("Paste");
		popupmenu.add(cut);
		popupmenu.add(copy);
		popupmenu.add(paste);
		frame.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				popupmenu.show(frame, e.getX(), e.getY());
			}
		});
		frame.add(popupmenu);
		frame.setSize(400, 400);
		frame.setLayout(null);
		frame.setVisible(true);
	}

	public static void main(String args[]) {
		new PopupMenuExample();
	}
}