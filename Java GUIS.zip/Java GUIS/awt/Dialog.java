import java.awt.*;
import java.awt.event.*;

public class DialogExample {
	private static Dialog dialog;

	DialogExample() {
		Frame frame = new Frame();
		dialog = new Dialog(frame, "Dialog Example", true);
		dialog.setLayout(new FlowLayout());
		Button button = new Button("OK");

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DialogExample.button.setVisible(false);
			}
		});

		dialog.add(new Label("Click button to continue."));
		dialog.add(button);
		dialog.setSize(300, 300);
		dialog.setVisible(true);
	}

	public static void main(String args[]) {
		new DialogExample();
	}
}