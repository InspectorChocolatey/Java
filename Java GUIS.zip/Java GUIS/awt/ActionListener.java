import java.awt.*;
import java.awt.event.*;

public class ActionListener {
	public static void main(String[] args) {
		Frame frame = new Frame("ActionListener");
		final TextField textfield = new TextField();
		textfield.setBounds(50, 50, 150, 20);
		Button button = new Button("Click Here");
		button.setBounds(50, 100, 60, 30);

		button.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				textfield.setText("Welcome to Javatpoint.");
			}

		});

		field.add(button);
		field.add(textfield);
		field.setSize(400, 400);
		field.setLayout(null);
		field.setVisible(true);
	}
}