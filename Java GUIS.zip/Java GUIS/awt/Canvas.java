import java.awt.*;

public class Canvas {
	public Canvas() {
		Frame frame = new Frame("Awt Canvas");
		frame.add(new MyCanvas());
		frame.setLayout(null);
		frame.setSize(400, 400);
		frame.setVisible(true);
	}

	public static void main(String args[]) {
		new CanvasExample();
	}
}

class MyCanvas extends Canvas {
	public MyCanvas() {
		setBackground(Color.GRAY);
		setSize(300, 200);
	}

	public void paint(Graphics graphic) {
		graphic.setColor(Color.red);
		graphic.fillOval(75, 75, 150, 75);
	}
}