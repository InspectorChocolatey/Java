package com.in28minutes.junit.helper;

import static org.junit.Assert.*;

import org.junit.Test;

public class StringHelperTest {

	
	StringHelper helper = new StringHelper();
	
	@Test
	public void truncateAInFirst2Positions_A() {
		//fail("Not yet implemented");
		//fail("Not yet implemented");
		//String expected = "ABC";
		//String actual = "ABCD";
		//String actual = "ABC";
		
		
		//StringHelper helper = new StringHelper();
		
		// Tests for StringHelper.truncateAInFirst2Positions("");
		//   AACD -> CD   ACD -> CD   CDEF -> CDEF  
			
		assertEquals("CD", helper.truncateAInFirst2Positions("AACD"));		
		assertEquals("CD", helper.truncateAInFirst2Positions("ACD"));
		assertEquals("CDEF", helper.truncateAInFirst2Positions("CDEF"));
		


	}

	//ABCD -> false, ABAB -> true, AB -> true, A -> false;
	
	@Test 
	public void areFirstAndLastTwoCharactersTheSame_A()
	{
		//StringHelper helper = new StringHelper();
		
		assertEquals(true, helper.areFirstAndLastTwoCharactersTheSame("AAbAA"));
		assertEquals(false, helper.areFirstAndLastTwoCharactersTheSame("AAbAa"));
		//assertEquals(true, helper.areFirstAndLastTwoCharactersTheSame("AAbAa"));
		assertEquals(false, helper.areFirstAndLastTwoCharactersTheSame("AAbAB"));
	}
}
